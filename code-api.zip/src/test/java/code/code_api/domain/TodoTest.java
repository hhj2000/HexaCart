package code.code_api.domain;

import code.code_api.repository.TodoRepository;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;

import java.time.LocalDate;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@Slf4j
class TodoTest {

    @Autowired
    TodoRepository todoRepository;

    @Test
    void 할일추가(){
        Todo todo = Todo.builder()
                .title("title...")
                .content("content")
                .dueDate(LocalDate.now())
                .build();
        todoRepository.save(todo);
    }

    @Test
    void 할일추가100(){
        for(int i=1; i<=100; i++){
            Todo todo = Todo.builder()
                        .title("Title..." + i)
                        .content("content..." + i)
                        .dueDate(LocalDate.now())
                        .build();
            todoRepository.save(todo);

        }
    }

    @Test
    void 삼십삼번조회(){
        long tno = 33L;
        Optional<Todo> findTodo = todoRepository.findById(tno);
        if(findTodo.isPresent()){
            assertEquals(33L, findTodo.get().getTno());
        }
    }

    @Test
    void 삼십삼번수정(){
        long tno = 33L;
        Optional<Todo> findTodo = todoRepository.findById(tno);

        Todo todo = findTodo.orElseThrow();
        todo.setTitle("title modify33");
        todo.setContent("content modify33");
        todo.setComplete(true);
        todo.setDueDate(LocalDate.of(2024, 12,4));
        todoRepository.save(todo);

    }

    @Test
    void 백일번삭제(){
        long tno = 101L;
        todoRepository.deleteById(tno);
    }

    @Test
    public void 페이징테스트(){
        //Pageable은 PageRequest.of(페이지번호, 사이즈)의 형태로 생성
        PageRequest pageable = PageRequest.of(0, 10, Sort.by("tno").descending());
        //findAll() 메서드를 통해서 한 번에 페이지에 대한 처리가 가능하다
        //findAll()의 결과는 Page<엔티티>타입으로 생성된다.
        Page<Todo> result = todoRepository.findAll(pageable);
        //데이터의 수가 충분하면 내부적으로 데이터베이스에 count쿼리를 같이 실행한다.
        log.info("결과 : {}", result.getTotalElements());
        result.getContent().stream().forEach(todo -> log.info("result {}", todo));
    }

//    @Test
//    public void 검색1(){
//        todoRepository.search1();
//    }
}