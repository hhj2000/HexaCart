package HEXACEPS.hexaceps.repository;

import HEXACEPS.hexaceps.domain.Cart;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Optional;


public interface CartRepository extends JpaRepository<Cart, Long> {

    @Query("select c from Cart c where c.cartId = :cartId")
    Optional<Cart> selectOne(@Param("cartId") int cartId);

    @Modifying
    @Query("delete from Cart c where c.cartId = :cartId")
    void Delete(@Param("cartId") int cartId);

    @Query("select c from Cart c order by c.cartId desc")
    Page<Cart> selectList(Pageable pageable);

}
