import React, { useState, useEffect } from 'react'
import useCustomMove from '../hook/useCustomMove'
import {Table} from 'react-bootstrap'
import PageComponent from '../component/PageComponent'
import { getList } from '../api/CartApi'

const initState = {
    cartIdList : [],
    pageNumList: [],
    pageRequestDTO: null,
}

const ListComponent = () => {
  const { page, size, moveToList, moveToRead } = useCustomMove()
    const [serverData, setServerData] = useState(initState)
    useEffect(() => {
        getList({page, size}).then(data => {
            console.log(data)
            setServerData(data)
        })
    }, [page, size])
  return (
    <>
    <Table striped bordered hover>
      <thead className = 'text-center'>
        <tr>
          <th>#</th>
          <th className = "w-75">title</th>
          <th>날짜</th>
        </tr>
      </thead>
      <tbody>
        {serverData.cartIdList.map(cart => (
          <tr key={cart.cartId}>
            <td className="text-center">{cart.cartId}</td>
            <td
              onClick={() => moveToRead(cart.cartId)}
              style={{ cursor: 'pointer' }}
              >
              {cart.productId || 'No Title'} {/* title 속성이 없는 경우 대비 */}
          </td>
      <td className="text-center">{cart.regAt}</td>
    </tr>
  ))}
</tbody>

    </Table>
    <PageComponent serverData={serverData} moveToList={moveToList}/>
    </>
  )
}

export default ListComponent