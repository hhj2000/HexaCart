import React from 'react'
import ModifyComponent from '../../component/ModifyComponent'
import {useParams} from 'react-router-dom'

const Modify = () => {
  const {cartId} = useParams()
  return (
    <>
    <div className = 'mb-5'>Modify</div>
    <ModifyComponent cartId = {cartId}/>
    </>
  )
}

export default Modify