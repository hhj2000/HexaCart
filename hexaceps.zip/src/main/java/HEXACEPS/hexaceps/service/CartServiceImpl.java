package HEXACEPS.hexaceps.service;

import HEXACEPS.hexaceps.domain.Cart;
import HEXACEPS.hexaceps.dto.CartDTO;
import HEXACEPS.hexaceps.dto.PageRequestDTO;
import HEXACEPS.hexaceps.dto.PageResponseDTO;
import HEXACEPS.hexaceps.repository.CartRepository;
import lombok.Builder;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Slf4j
@RequiredArgsConstructor
@Builder
@Service
public class CartServiceImpl implements CartService{
    private final CartRepository cartRepository;

    //목록데이터 조회
    @Override
    public PageResponseDTO<CartDTO> getList(PageRequestDTO pageRequestDTO) {
        //페이지목록 만들기
        Pageable pageable = PageRequest.of(
                pageRequestDTO.getPage() - 1,
                pageRequestDTO.getSize(),
                Sort.by("cartId").descending()
        );

        //리포지터리에 가서 목록 가져온다
        Page<Cart> result = cartRepository.selectList(pageable);

        List<CartDTO> dtoList = result.stream().map(this::convertToDto).toList();
        long totalCount = result.getTotalElements();
        int totalPages = (int) Math.ceil((double) totalCount / pageRequestDTO.getSize());

        // Create page numbers list
        List<Integer> pageNumList = new ArrayList<>();
        for (int i = 1; i <= totalPages; i++) {
            pageNumList.add(i);
        }
        return PageResponseDTO.<CartDTO>builder()
                .cartIdList(dtoList)
                .pageNumList(pageNumList)
                .pageRequestDTO(pageRequestDTO)
                .build();
    }

    private CartDTO convertToDto(Cart cart) {
        return CartDTO.builder()
                .cartId(cart.getCartId())
                .categoryId(cart.getCategoryId())
                .userId(cart.getUserId())
                .size(cart.getSize())
                .amount(cart.getAmount())
                .productId(cart.getProductId())
                .regAt(cart.getRegAt())
                .build();
    }

    public Integer register(CartDTO cartDTO){
        Cart cart = cartIdToEntity(cartDTO);
        log.info("새로운 장바구니 상품: {}", cart);
        Integer cartId = cartRepository.save(cart).getCartId();
        return cartId;
    }

    private Cart cartIdToEntity(CartDTO cartDTO){
        Cart cart = Cart.builder()
                .categoryId(cartDTO.getCategoryId())
                .productId(cartDTO.getProductId())
                .userId(cartDTO.getUserId())
                .size(cartDTO.getSize())
                .amount(cartDTO.getAmount())
                .regAt(cartDTO.getRegAt())
                .build();
        return cart;
    }

    private CartDTO entityToCartId(Cart cart){
        CartDTO cartDTO = CartDTO.builder()
                .cartId(cart.getCartId())
                .categoryId(cart.getCategoryId())
                .productId(cart.getProductId())
                .userId(cart.getUserId())
                .size(cart.getSize())
                .amount(cart.getAmount())
                .regAt(cart.getRegAt())
                .build();
        return cartDTO;
    }

    @Override
    public CartDTO get(Integer cartId) {
        Optional<Cart> result = cartRepository.selectOne(cartId);
        Cart cart = result.orElseThrow();
        CartDTO cartDTO = entityToCartId(cart);
        return cartDTO;
    }

    @Override
    public void modify(CartDTO cartDTO) {
        Optional<Cart> result = cartRepository.selectOne(cartDTO.getCartId());

        Cart cart = result.orElseThrow();

        cart.setCategoryId(cartDTO.getCategoryId());
        cart.setProductId(cartDTO.getProductId());
        cart.setUserId(cartDTO.getUserId());
        cart.setSize(cartDTO.getSize());
        cart.setAmount(cartDTO.getAmount());
        cart.setRegAt(cartDTO.getRegAt());

        cartRepository.save(cart);
    }

    @Override
    public void remove(Integer cartId) {
        cartRepository.deleteById((long)cartId);
    }

}
