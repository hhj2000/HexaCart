package code.code_api.util;

import io.jsonwebtoken.*;
import io.jsonwebtoken.security.Keys;
import lombok.extern.slf4j.Slf4j;

import javax.crypto.SecretKey;
import java.io.UnsupportedEncodingException;
import java.sql.Date;
import java.time.ZonedDateTime;
import java.util.Map;

@Slf4j
public class JWTUtil {

    //JWT의 서명을 생성할 때 사용하는 비밀 키, 최소 256비트(32자 이상)가 필요
    //HMAC-SHA 알고리즘을 사용
    private static String key = "1234567890123456789012345678901234567890";

    //JWT 문자열 생성을 위한 generatedToken() 메서드
    //입력으로 전달된 valueMap과 유효 시간(min)을 바탕으로 JWT 생성
    //valueMap은 JWT의 클레임(Claims)입니다. 예를 들어, 사용자 정보 같은 데이터를 담을 수 있습니다.
    public static String generatedToken(Map<String, Object> valueMap, int min){
        SecretKey key = null;
        //hmacShaKeyFor, 비밀키를 HMAC-SHA 알고리즘용 키로 변환
        try {
            key = Keys.hmacShaKeyFor(JWTUtil.key.getBytes("UTF-8"));
        } catch (UnsupportedEncodingException e) {
            throw new RuntimeException(e);
        }

        String jwtStr = Jwts.builder()
                .setHeader(Map.of("typ", "JWT"))
                .setClaims(valueMap)
                .setIssuedAt(Date.from(ZonedDateTime.now().toInstant()))
                .setExpiration(Date.from(ZonedDateTime.now().plusMinutes(min)
                                .toInstant()))
                        .signWith(key)
                        .compact();
        return jwtStr;
    }
    //검증을 위한 validateToken
    //입력값 token은 검증대상의 JWT문자열
    public static Map<String, Object> validateToken(String token){
        //토큰의 클레임 데이터를 저장할 변수, 클레임은 토큰에 담긴 정보(key-value쌍)으로 이루어짐
        Map<String, Object> claim = null;
        //비밀키
        SecretKey key = null;

        try {
            key = Keys.hmacShaKeyFor(JWTUtil.key.getBytes("UTF-8"));
            claim = Jwts.parserBuilder()
                    .setSigningKey(key)
                    .build()
                    .parseClaimsJws(token)
                    .getBody();
        }catch (MalformedJwtException malformedJwtException) {
            throw new CustomJWTException("Malformed");
        }catch (ExpiredJwtException expiredJwtException) {
            throw new CustomJWTException("Expired");
        }catch (InvalidClaimException invalidClaimException) {
            throw new CustomJWTException("Invalid");
        }catch (JwtException jwtException) {
            throw new CustomJWTException("JWTError");
        }catch (Exception e) {
            throw new CustomJWTException("Error");
        }
        
        return claim;
    }
}
