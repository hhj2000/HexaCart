import React, {useState} from 'react'
import { Button, Form } from 'react-bootstrap'
import { postAdd } from '../api/CartApi'

const initState = {
  categoryId: '',
  userId: '',
  productId: '',
  size: 0,
  amount: 0,
  regAt: ''
}

const AddComponent = () => {
  const [cart, setCart] = useState(initState)
  const handleChangeCart = (e) => {
    cart[e.target.name] = e.target.value
    setCart({...cart})
  }
  const handleClickAdd = () => {
    console.log(cart)
    postAdd(cart).then(result => {
      console.log(result)
      setCart({...initState})
    }).catch(e => {
      console.error(e)
    })
  }
  return (
    <>
    <Form.Group className="mb-3">
        <Form.Label>CATEGORYID</Form.Label>
        <Form.Control type={"text"} name="categoryId" placeholder="카테고리 아이디를 입력하세요" onChange={handleChangeCart} />
      </Form.Group>
      <Form.Group className="mb-3">
        <Form.Label>USERID</Form.Label>
        <Form.Control type={"text"} name="userId" placeholder="유저 아이디를 입력하세요" onChange={handleChangeCart}/>
      </Form.Group>
      <Form.Group className="mb-3">
        <Form.Label>PRODUCTID</Form.Label>
        <Form.Control type={"text"} name="productId" placeholder="제품 아이디를 입력하세요" onChange={handleChangeCart}/>
      </Form.Group>
      <Form.Group className="mb-3">
        <Form.Label>SIZE</Form.Label>
        <Form.Control type="number" name="size" onChange={handleChangeCart}/>
      </Form.Group>
      <Form.Group className="mb-3">
        <Form.Label>AMOUNT</Form.Label>
        <Form.Control type="number" name="amount" onChange={handleChangeCart}/>
      </Form.Group>
      <Form.Group className="mb-3">
        <Form.Label>REGAT</Form.Label>
        <Form.Control type={"date"} name="regAt" onChange={handleChangeCart} placeholder="yyyy-MM-dd"/>
      </Form.Group>
      <Button variant="primary" type="button" onClick = {handleClickAdd}>추가</Button>
    </>
  )
}

export default AddComponent