package code.code_api.repository.search;

import code.code_api.domain.Product;
import code.code_api.domain.QProduct;
import code.code_api.domain.QProductImage;
import code.code_api.dto.PageRequestDTO;
import code.code_api.dto.PageResponseDTO;
import code.code_api.dto.ProductDTO;
import com.querydsl.core.Tuple;
import com.querydsl.jpa.JPQLQuery;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.support.QuerydslRepositorySupport;

import java.util.List;

@Slf4j
public class ProductSearchImpl extends QuerydslRepositorySupport implements ProductSearch {

    //생성자
    public ProductSearchImpl(){
        super(Product.class);
    }

    //메서드 재정의
    @Override
    public PageResponseDTO<ProductDTO> searchList(PageRequestDTO pageRequestDTO){
        log.info("ProductSearchImpl? 동작하고 있어?");
        Pageable pageable = PageRequest.of(
                pageRequestDTO.getPage()-1,
                pageRequestDTO.getSize(),
                Sort.by("pno").descending()
        );
        QProduct product = QProduct.product;
        QProductImage productImage = QProductImage.productImage;

        //jpql쿼리를 뽑는다. product로부터 query를 뽑는다.
        JPQLQuery<Product> query = from(product);

        //상품인데 이미지가 없을 수도 있으므로 leftjoin
        query.leftJoin(product.imageList, productImage);

        //where 조건 추가, 이미지는 0번째 것만 가져와
        query.where(productImage.ord.eq(0));

        //페이징처리
        getQuerydsl().applyPagination(pageable, query);
        //List<Product> productList1 = query.fetch();

        //만약 상품과 상품 이미지를 뽑고 싶으면
        List<Tuple> productList2 = query.select(product, productImage).fetch();
        long count = query.fetchCount();

        //log.info("상품리스트1 {}", productList1);
        log.info("상품리스트2 {}", productList2);

        return null;
    }
}
