package HEXACEPS.hexaceps.dto;

import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
public class PageResponseDTO<E> {

    //Cart_id 목록
    private List<E> cartIdList;

    //pageNumList
    private List<Integer> pageNumList;

    //현재 페이지 정보
    private PageRequestDTO pageRequestDTO;

}
