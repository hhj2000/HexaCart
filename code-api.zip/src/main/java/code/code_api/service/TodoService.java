package code.code_api.service;

import code.code_api.domain.Todo;
import code.code_api.dto.PageRequestDTO;
import code.code_api.dto.PageResponseDTO;
import code.code_api.dto.TodoDTO;

public interface TodoService {
    //조회기능
    TodoDTO get(Long tno);

    //등록하기
    Long register(TodoDTO dto);

    //수정하기
    void modify(TodoDTO dto);

    //삭제하기
    void remove(Long tno);

    PageResponseDTO<TodoDTO> getlist(PageRequestDTO pageRequestDTO);

    //java8버전부터는 default 기능이 추가되어 기본 기능을 설정해 줄 수 있다.
    //엔티티를 DTO로 변환
    default TodoDTO entityToDTO(Todo todo){
        TodoDTO todoDTO = TodoDTO.builder()
                .tno(todo.getTno())
                .title(todo.getTitle())
                .content(todo.getContent())
                .complete(todo.isComplete())
                .dueDate(todo.getDueDate())
                .build();
        return todoDTO;
    }

    //DTO를 엔티티로 변환
    default Todo dtoToEntity(TodoDTO todoDTO) {
        Todo todo = Todo.builder()
                .tno(todoDTO.getTno())
                .title(todoDTO.getTitle())
                .content(todoDTO.getContent())
                .complete(todoDTO.isComplete())
                .dueDate(todoDTO.getDueDate())
                .build();
        return todo;
    }
}
