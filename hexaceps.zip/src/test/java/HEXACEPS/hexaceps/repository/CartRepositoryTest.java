package HEXACEPS.hexaceps.repository;

import HEXACEPS.hexaceps.domain.Cart;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.Optional;

@SpringBootTest
@Slf4j
class CartRepositoryTest {

    @Autowired
    private CartRepository cartRepository;

    @Test
    public void saveCartTest() {
        // Given: 새로운 Cart 객체 생성
        Cart cart = Cart.builder()
                .categoryId("shoes")
                .userId("testUser")
                .productId("product123")
                .size(42)
                .amount(3)
                .regAt(LocalDate.now())
                .build();

        // When: Cart 객체 저장
        Cart savedCart = cartRepository.save(cart);
    }

    @Transactional
    @Test
    void 상품조회1(){
        long cart_id = 1L;
        Optional<Cart> result = cartRepository.findById(cart_id);
        Cart cart = result.orElseThrow();
        log.info("결과 {}", cart.getUserId());
    }

    @Test
    void 상품추가10(){
        for(int i = 1; i<=10; i++){
            Cart cart = Cart.builder()
                    .categoryId("shoes..." + i)
                    .userId("testUser..." + i)
                    .productId("product..." + i)
                    .size(i)
                    .amount(i)
                    .regAt(LocalDate.now())
                    .build();
            Cart savedCart = cartRepository.save(cart);
        }
    }

    @Test
    void 수정해보기(){
        long cart_id = 11L;
        Optional<Cart> find11 = cartRepository.findById(cart_id);

        Cart cart = find11.orElseThrow();
        cart.setProductId("twelve");
        cart.setSize(250);
        cart.setAmount(3);
        cart.setUserId("MyDecision");
        cart.setRegAt(LocalDate.of(2024, 12,4));
        cart.setCategoryId("snickers");

        cartRepository.save(cart);
    }

    @Test
    void 삭제11번(){
        long cart_id = 12L;
        cartRepository.deleteById(cart_id);
    }

    @Test
    void 상품리스트조회(){
        Pageable pageable = PageRequest.of(0, 10, Sort.by("cartId").descending());

        Page<Cart> result = cartRepository.selectList(pageable);

        result.getContent().forEach(cart -> log.info("Cart ID: {}, Category ID : {}, User ID : {}, Product Name: {}, Size: {}, Amount: {}, Reg at : {}", cart.getCartId(), cart.getCategoryId(), cart.getUserId(), cart.getProductId(), cart.getSize(), cart.getAmount(), cart.getRegAt()));
    }


    @Test
    public void 페이징테스트(){
        //Pageable은 PageRequest.of(페이지번호, 사이즈)의 형태로 생성
        PageRequest pageable = PageRequest.of(0, 10, Sort.by("cartId").descending());
        //findAll() 메서드를 통해서 한 번에 페이지에 대한 처리가 가능하다
        //findAll()의 결과는 Page<엔티티>타입으로 생성된다.
        Page<Cart> result = cartRepository.findAll(pageable);
        //데이터의 수가 충분하면 내부적으로 데이터베이스에 count쿼리를 같이 실행한다.
        log.info("결과 : {}", result.getTotalElements());
        result.getContent().stream().forEach(cart -> log.info("result {}", cart));
    }




}