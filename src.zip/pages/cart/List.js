import React from 'react'
import ListComponent from '../../component/ListComponent'

const List = () => {
  return (
    <>
    <div className='mb-5'> Cart</div>
    <ListComponent/>
    </>
  )
}

export default List