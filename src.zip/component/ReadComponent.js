import React, {useEffect, useState} from 'react'
import { getOne } from '../api/CartApi';
import {Button, Card} from 'react-bootstrap';
import useCustomMove from '../hook/useCustomMove'
import {useParams} from 'react-router-dom'

const initState = {
  cartId: 0,
  categoryId: '',
  userId: '',
  productId: '',
  size: 0,
  amount: 0,
  regAt: ''
}

const ReadComponent = () => {
  const { cartId } = useParams();
  const [cart, setCart] = useState(initState);
  const {moveToList, moveToModify} = useCustomMove();
  useEffect(() => {
      getOne(cartId).then(data =>{ 
        console.log(data)
        setCart(data)
      })
  }, [cartId])
  return (
    <>
      {makeDiv('cartId', cart.cartId)}
      {makeDiv('categoryId', cart.categoryId)}
      {makeDiv('userId', cart.userId)}
      {makeDiv('productId', cart.productId)}
      {makeDiv('size', cart.size)}
      {makeDiv('amount', cart.amount)}
      {makeDiv('regAt', cart.regAt)}
      <div className = "mt-3 text-end">
      <Button variant="primary" className = 'me-3' onClick={moveToList}>목록보기</Button>
      <Button variant="secondary" onClick={() => moveToModify(cart.cartId)}>수정</Button>
      </div>
    </>
  )
}

function makeDiv(title, value) {
  return (
    <Card className="mx-auto mb-2">
      <Card.Body className='d-flex'>
        <Card.Title className="w-25 text-primary">{title}</Card.Title>
        <Card.Text>
          : { value }
        </Card.Text>
      </Card.Body>
    </Card>
  );
}

export default ReadComponent