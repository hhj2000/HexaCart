import React from 'react'
import AddComponent from '../../component/AddComponent'

const Add = () => {
  return (
    <>
    <div className='mb-5'>Add</div>
    <AddComponent/>
    </>
  )
}

export default Add