package HEXACEPS.hexaceps.service;

import HEXACEPS.hexaceps.dto.CartDTO;
import HEXACEPS.hexaceps.dto.PageRequestDTO;
import HEXACEPS.hexaceps.dto.PageResponseDTO;


public interface CartService {
    //장바구니 목록
    PageResponseDTO<CartDTO> getList(PageRequestDTO pageRequestDTO);
    //장바구니 추가
    Integer register(CartDTO cartDTO);
    //조회 기능
    CartDTO get(Integer cartId);
    //수정하기
    void modify(CartDTO cartDTO);
    //삭제하기
    void remove(Integer cartId);

}
