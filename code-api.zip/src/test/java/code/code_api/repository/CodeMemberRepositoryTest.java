package code.code_api.repository;

import code.code_api.domain.CodeMember;
import code.code_api.domain.MemberRole;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.crypto.password.PasswordEncoder;

@SpringBootTest
@Slf4j
public class CodeMemberRepositoryTest {

    @Autowired private CodeMemberRepository codeMemberRepository;
    @Autowired private PasswordEncoder passwordEncoder;

    //회원10명 등록, 5번 이상은 MEMBER, 9번 이상은 ADMIN 부여
    @Test
    public void 회원1명가입(){
        for(int i = 0; i<10; i++){
            CodeMember member = CodeMember.builder()
                    .email("user" + i + "@aaa.com")
                    .pw(passwordEncoder.encode("1111"))
                    .nickname("user" + i)
                    .build();

            member.addRole(MemberRole.USER);
            if(i>=5) member.addRole(MemberRole.MANAGER);
            if(i>=8) member.addRole(MemberRole.ADMIN);

            codeMemberRepository.save(member);
        }
    }

    @Test
    public void 구번조회(){
        String email = "user9@aaa.com";
        CodeMember member = codeMemberRepository.getWithRoles(email);
        log.info("9번 회원 {}", member);
        log.info("9번 회원의 권한은? {}", member.getMemberRoleList());

    }
}
