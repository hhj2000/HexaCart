package code.code_api.domain;

import jakarta.persistence.ElementCollection;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import lombok.*;

import java.util.ArrayList;
import java.util.List;

@Entity
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@ToString(exclude = "memberRoleList")
public class CodeMember {

    @Id
    private String email;

    private String pw;

    private  String nickname;

    //소셜로그인, true-소셜로그인사용자, false-일반 사용자
    private boolean social;

    //memberRoleList가 실제로 사용될 때 데이터를 로드
    @ElementCollection(fetch = FetchType.LAZY)
    @Builder.Default
    private List<MemberRole> memberRoleList = new ArrayList<>();

    //권한부여
    public void addRole(MemberRole memberRole){
        memberRoleList.add(memberRole);
    }

    //권한삭제
    public void clearRole(){
        memberRoleList.clear();
    }

    //nickname, pw, social은 변경가능하게
    public void setPw(String pw) {
        this.pw = pw;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public void setSocial(boolean social) {
        this.social = social;
    }
}


