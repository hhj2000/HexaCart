package HEXACEPS.hexaceps.config;

import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
@Slf4j
public class CustomServletConfig implements WebMvcConfigurer {
    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/api/cart/**") //모든 경로에 설정
                .maxAge(500) //연결이 안 될 때, 서버에 문제가 있다고 생각하고 빨리 끊어준다
                .allowedMethods("GET", "POST", "PUT", "DELETE") // 어떤 방식의 호출을 허용할 건지 한 번 해보는 것
                .allowedOrigins("*"); // 모든 경로에서 들어오는 것 허용
    }
}
