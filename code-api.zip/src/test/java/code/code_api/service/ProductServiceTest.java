package code.code_api.service;

import code.code_api.dto.PageRequestDTO;
import code.code_api.dto.PageResponseDTO;
import code.code_api.dto.ProductDTO;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;
import java.util.UUID;

@SpringBootTest
@Slf4j
public class ProductServiceTest {

    @Autowired
    ProductService productService;

    @Test
    void 상품조회(){
        //기본1페이지, 10개
        PageRequestDTO pageRequestDTO = PageRequestDTO.builder().build();
        PageResponseDTO<ProductDTO> result = productService.getList(pageRequestDTO);

        result.getDtoList().forEach(dto -> log.info("상품리스트 : {}", dto));
    }

    @Test
    void 상품저장(){
        ProductDTO productDTO = ProductDTO.builder()
                .pname("새로운상품추가")
                .pdesc("2024년 겨울 신상")
                .price(15000)
                .build();
        //UUID필요
        productDTO.setUploadFileNames(
                List.of(
                        UUID.randomUUID() + "_" + "new1.jpg",
                        UUID.randomUUID() + "_" + "new2.jpg"
                        )
        );

        productService.register(productDTO);
    }

    //상품 가져오기
    @Test
    public void 상품1번가져오기(){
        Long pno = 1L;
        ProductDTO productDTO = productService.get(pno);
        log.info("찾은 상품 {}", productDTO);
        log.info("찾은 상품 이미지 {}", productDTO.getUploadFileNames());
    }
}
