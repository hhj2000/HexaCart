package HEXACEPS.hexaceps.domain;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;

@Entity
@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Cart {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "cart_id") // DB의 컬럼 이름은 snake_case
    private int cartId;

    @Column(name = "category_id")
    private String categoryId;

    @Column(name = "user_id")
    private String userId;

    @Column(name = "product_id")
    private String productId;

    private int size;
    private int amount;

    @Column(name = "reg_at")
    private LocalDate regAt;

    public void setCategoryId(String categoryId) {this.categoryId = categoryId;}

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    public void setRegAt(LocalDate regAt) {
        this.regAt = regAt;
    }


}
