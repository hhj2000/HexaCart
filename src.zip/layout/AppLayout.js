import React from 'react'
import {Outlet} from 'react-router-dom';
import {Container, Row, Col, Nav, Navbar, NavDropdown} from 'react-bootstrap'

const AppLayout = () => {
  return (
    <div>
        <Navbar expand="lg" className="bg-body-tertiary mb-5">
        <Container>
          <Navbar.Brand href="/">HexaCart</Navbar.Brand>
          <Navbar.Toggle aria-controls="basic-navbar-nav" />
          <Navbar.Collapse id="basic-navbar-nav">
            <Nav className="me-auto">
                <NavDropdown title="Cart" id="basic-nav-dropdown">
                  <NavDropdown.Item href="/add">add</NavDropdown.Item>
                  <NavDropdown.Item href="/list">list</NavDropdown.Item>
                </NavDropdown>
            </Nav>
          </Navbar.Collapse>
        </Container>
      </Navbar>
      <Container>
        <Row>
          <Col><Outlet /></Col>
        </Row>
      </Container>
      <Container>
        <div className = 'bg-body-tertiary border-top mt-5 py-2 text-center'>
          ALL RIGHT RESERVED BY © 이젠IT AN
        </div>
      </Container>
    </div>
  )
}

export default AppLayout