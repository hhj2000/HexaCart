package code.code_api.domain;

public enum MemberRole {

    USER, MANAGER, ADMIN
}

