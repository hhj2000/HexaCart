package code.code_api.repository;

import code.code_api.domain.Product;
import code.code_api.domain.Todo;
import code.code_api.dto.PageRequestDTO;
import code.code_api.dto.PageResponseDTO;
import code.code_api.dto.ProductDTO;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.test.annotation.Commit;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.Optional;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@Slf4j
public class ProductRepositoryTest {

    @Autowired
    ProductRepository productRepository;

    //상품 + 이미지 2개 저장해보자
    @Test
    public void 상품추가(){
        Product product = Product.builder()
                .pname("test상품1")
                .price(20000)
                .pdesc("상품설명")
                .build();
        //이미지 2개, 이름 추가
        product.addImageString(UUID.randomUUID().toString() + "_" + "image1.jpg");
        product.addImageString(UUID.randomUUID().toString() + "_" + "image2.jpg");

        productRepository.save(product);
        log.info("저장완료 {}", product.getPname());
    }

    //상품 1번 조회
    @Transactional
    @Test
    void 상품조회1(){
        Long pno = 1L;
        Optional<Product> result = productRepository.findById(pno);
        Product product = result.orElseThrow();
        log.info("결과 {}", product.getPname());
        log.info("이미지결과 {}", product.getImageList());
    }

    @Test
    public void 상품조회2(){
        Long pno = 1L;
        Optional<Product> result = productRepository.selectOne(pno);
        Product product = result.orElseThrow();
        log.info("결과 {}", product.getPname());
        log.info("이미지결과 {}", product.getImageList());
    }

    @Commit
    @Transactional
    @Test
    void 삭제1번(){
        Long pno = 1L;
        productRepository.updateToDelete(pno, true);
    }

    @Test
    public void 열개추가(){
        for(int i=1; i<=10; i++) {
            Product product = Product.builder()
                    .pname("test상품" + i)
                    .price(20000)
                    .pdesc("상품설명" + i)
                    .build();
            product.addImageString(UUID.randomUUID().toString() + "_" + "image1.jpg");
            product.addImageString(UUID.randomUUID().toString() + "_" + "image2.jpg");
            productRepository.save(product);
            log.info("저장완료 {}", product.getPname());
        }
    }

    //3번 상품 수정
    //수정3, 수정 설명3, 25000, 일단 지우고 이미지 3개 추가
    @Test
    void 삼번상품수정(){
        Long pno = 3L;
        Product product = productRepository.selectOne(pno).get();
        product.setPname("수정3");
        product.setPdesc("수정 설명 3");
        product.setPrice(25000);
        product.clearList();
        product.addImageString(UUID.randomUUID().toString() + "_" + "newimage1.jpg");
        product.addImageString(UUID.randomUUID().toString() + "_" + "newimage2.jpg");
        product.addImageString(UUID.randomUUID().toString() + "_" + "newimage3.jpg");
        productRepository.save(product);
    }

    @Test
    void 상품리스트조회(){
        Pageable pageable = PageRequest.of(0, 10, Sort.by("pno").descending());

        Page<Object[]> result = productRepository.selectList(pageable);

        result.getContent().forEach(arr -> log.info(Arrays.toString(arr)));
    }

    //상품검색테스트
    @Test
    void 상품검색(){
        PageRequestDTO pageRequestDTO = PageRequestDTO.builder().build();
        PageResponseDTO<ProductDTO> result =
        productRepository.searchList(pageRequestDTO);

        result.getDtoList().forEach(dto -> log.info("상품리스트 {}", dto));

    }

    //[[Product(pno=11, pname=test상품10, price=20000, pdesc=상품설명10, delFlag=false), ProductImage(fileName=563bc4d6-2447-4d09-851e-ad73ce70529d_image10.jpg, ord=0)], [], []]
}
