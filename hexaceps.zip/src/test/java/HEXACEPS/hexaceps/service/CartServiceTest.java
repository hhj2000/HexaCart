package HEXACEPS.hexaceps.service;

import HEXACEPS.hexaceps.dto.CartDTO;
import HEXACEPS.hexaceps.dto.PageRequestDTO;
import HEXACEPS.hexaceps.dto.PageResponseDTO;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.time.LocalDate;

@SpringBootTest
@Slf4j
public class CartServiceTest {

    @Autowired
    CartService cartService;

    @Test
    void 조회(){
        Integer cartId = 1;
        log.info("1번 {}", cartService.get(cartId));
    }

    @Test
    void 등록(){
        CartDTO cartDTO = CartDTO.builder()
                .userId("AtLast")
                .amount(12)
                .size(260)
                .categoryId("snickers")
                .productId("finally")
                .regAt(LocalDate.now())
                .build();
        log.info("추가 {}", cartService.register(cartDTO));
    }

    @Test
    void 페이징리스트(){
        PageRequestDTO pageRequestDTO = PageRequestDTO.builder().build();
        log.info("페이징리스트의 기본값 {}", cartService.getList(pageRequestDTO));
    }

    @Test
    void 페이징리스트1번(){
        PageRequestDTO pageRequestDTO = PageRequestDTO.builder().page(1).build();
        log.info("1번페이지 {}", cartService.getList(pageRequestDTO));
    }

    @Test
    void 상품조회(){
        //기본1페이지, 10개
        PageRequestDTO pageRequestDTO = PageRequestDTO.builder().build();
        PageResponseDTO<CartDTO> result = cartService.getList(pageRequestDTO);

        result.getCartIdList().forEach(cart -> log.info("상품리스트 : {}", cart));
    }
}
