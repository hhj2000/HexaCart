package code.code_api.service;

import code.code_api.dto.PageRequestDTO;
import code.code_api.dto.PageResponseDTO;
import code.code_api.dto.ProductDTO;

public interface ProductService {

    //상품 리스트
    PageResponseDTO<ProductDTO> getList(PageRequestDTO pageRequestDTO);

    //상품 추가
    Long register(ProductDTO productDTO);

    //조회 기능
    ProductDTO get(Long pno);

    //수정하기
    void modify(ProductDTO productDTO);

    //삭제하기
    void remove(Long pno);
}
