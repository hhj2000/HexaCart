import React, { useState, useEffect } from 'react';
import { Form, Button } from 'react-bootstrap';
import { getOne, putOne, deleteOne } from '../api/CartApi';
import { useParams } from 'react-router-dom';

const initState = {
  cartId: 0,
  categoryId: '',
  userId: '',
  productId: '',
  size: 0,
  amount: 0,
  regAt: ''
};

const ModifyComponent = () => {
  const { cartId } = useParams();
  const [cart, setCart] = useState({ ...initState });

  useEffect(() => {
    const fetchData = async () => {
      try {
        const data = await getOne(cartId);
        setCart(data);
      } catch (error) {
        console.error("데이터 로드 실패:", error);
      }
    };
    fetchData();
  }, [cartId]);

  const handleChangeCart = (e) => {
    const { name, value } = e.target;
    setCart((prevCart) => ({
      ...prevCart,
      [name]: value,
    }));
  };

  const handleClickModify = () => {
    putOne(cart)
      .then((data) => {
        console.log("수정 완료: ", data);
      })
      .catch((error) => {
        console.error("수정 실패: ", error);
      });
  };

  const handleClickDelete = () => {
    deleteOne(cart.cartId)
      .then((data) => {
        console.log("삭제 완료: ", data);
      })
      .catch((error) => {
        console.error("삭제 실패: ", error);
      });
  };

  return (
    <>
      <Form.Group className="mb-3">
        <Form.Label>CARTID</Form.Label>
        <Form.Control
          type="number"
          name="cartId"
          value={cart.cartId}
          onChange={handleChangeCart}
          readOnly
        />
      </Form.Group>
      <Form.Group className="mb-3">
        <Form.Label>CATEGORYID</Form.Label>
        <Form.Control
          type="text"
          name="categoryId"
          placeholder="카테고리 아이디를 입력하세요"
          value={cart.categoryId}
          onChange={handleChangeCart}
        />
      </Form.Group>
      <Form.Group className="mb-3">
        <Form.Label>USERID</Form.Label>
        <Form.Control
          type="text"
          name="userId"
          placeholder="유저 아이디를 입력하세요"
          value={cart.userId}
          onChange={handleChangeCart}
        />
      </Form.Group>
      <Form.Group className="mb-3">
        <Form.Label>PRODUCTID</Form.Label>
        <Form.Control
          type="text"
          name="productId"
          placeholder="제품 아이디를 입력하세요"
          value={cart.productId}
          onChange={handleChangeCart}
        />
      </Form.Group>
      <Form.Group className="mb-3">
        <Form.Label>SIZE</Form.Label>
        <Form.Control
          type="number"
          name="size"
          value={cart.size}
          onChange={handleChangeCart}
        />
      </Form.Group>
      <Form.Group className="mb-3">
        <Form.Label>AMOUNT</Form.Label>
        <Form.Control
          type="number"
          name="amount"
          value={cart.amount}
          onChange={handleChangeCart}
        />
      </Form.Group>
      <Form.Group className="mb-3">
        <Form.Label>REGAT</Form.Label>
        <Form.Control
          type="date"
          name="regAt"
          placeholder="yyyy-MM-dd"
          value={cart.regAt}
          onChange={handleChangeCart}
        />
      </Form.Group>
      <div className="mt-3 text-end">
        <Button variant="primary" className="me-3" onClick={handleClickModify}>
          수정
        </Button>
        <Button variant="secondary" onClick={handleClickDelete}>
          삭제
        </Button>
      </div>
    </>
  );
};

export default ModifyComponent;