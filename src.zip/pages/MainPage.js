import React from 'react'

const MainPage = () => {
  return (
    <>
    <p>About</p>
    <div>MainPage</div>
    </>
  )
}

export default MainPage