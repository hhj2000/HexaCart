package HEXACEPS.hexaceps.controller;

import HEXACEPS.hexaceps.dto.CartDTO;
import HEXACEPS.hexaceps.dto.PageRequestDTO;
import HEXACEPS.hexaceps.dto.PageResponseDTO;
import HEXACEPS.hexaceps.service.CartService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@Slf4j
@RequiredArgsConstructor
@RequestMapping("/api/cart")
public class CartController {
    private final CartService cartService;

    @PostMapping("/")
    public Map<String, Integer> register(@RequestBody CartDTO cartDTO){
        log.info("register : {}", cartDTO);
        Integer cartId = cartService.register(cartDTO);
        try{
            Thread.sleep(2000);
        }catch(InterruptedException e){
            throw new RuntimeException(e);
        }
        return Map.of("result", cartId);
    }

    @GetMapping("/list")
    public PageResponseDTO<CartDTO> list(PageRequestDTO pageRequestDTO){
        return cartService.getList(pageRequestDTO);
        }

    @GetMapping("/{cartId}")
    public CartDTO read(@PathVariable("cartId") Integer cartId){
        return cartService.get(cartId);
    }

    @DeleteMapping("{cartId}")
    public Map<String, String> remove(@PathVariable("cartId") Integer cartId){
        cartService.remove(cartId);
        return Map.of("RESULT", "DELETE SUCCESS");
    }

    @PutMapping("/{cartId}")
    public Map<String, String> modify(@PathVariable("cartId") Integer cartId, @RequestBody CartDTO cartDTO){
        cartDTO.setCartId(cartId);

        cartService.modify(cartDTO);

        return Map.of("RESULT", "MODIFY SUCCESS");
    }


}
