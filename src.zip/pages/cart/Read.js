import React from 'react'
import ReadComponent from '../../component/ReadComponent'
import {useParams} from 'react-router-dom';
const Read = () => {
    const {cartId} = useParams()
  return (
    <>
    <div className='mb-5'>Read</div>
    <ReadComponent cartId = {cartId}/>
    </>
  )
}

export default Read