import axios from 'axios'

export const API_SERVER_HOST = 'http://localhost:8080'

const prefix = `${API_SERVER_HOST}/api/cart`


//특정 번호의 cartId 조회
export const getOne = async(cartId) => {
    const res = await axios.get(`${prefix}/${cartId}`);
    return res.data
}

//list
export const getList = async(pageParam) => {
    const {page,size} = pageParam 
    const res = await axios.get(`${prefix}/list`, {params: {page:page, size:size}})
    console.log(res)
    
    return res.data
}

// //데이터 추가
export const postAdd = async(cart) => {
    const res = await axios.post(`${prefix}/`, cart)
    return res.data
}

// //수정
export const putOne = async(cart) => {
    const res = await axios.put(`${prefix}/${cart.cartId}`, cart)
    return res.data
}

// //삭제
export const deleteOne = async(cartId) => {
    const res = await axios.delete(`${prefix}/${cartId}`)
    return res.data
}