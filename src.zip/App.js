import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import {Route, Routes} from 'react-router-dom';
import AppLayout from './layout/AppLayout';
import MainPage from './pages/MainPage';
import Modify from './pages/cart/Modify';
import Add from './pages/cart/Add';
import List from './pages/cart/List';
import Read from './pages/cart/Read';

function App() {
  return (
    <Routes>
      <Route path="/" element={<AppLayout />}>
        <Route index element={<MainPage />} />
        <Route path="list" element={<List />} />
        <Route path="modify/:cartId" element={<Modify />} />
        <Route path="add" element={<Add />} />
        <Route path="read/:cartId" element={<Read />} />
      </Route>
    </Routes>
  );
}

export default App;
