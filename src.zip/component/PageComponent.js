import React from 'react'
import { Pagination } from 'react-bootstrap'

const PageComponent = ({serverData, moveToList}) => {
   const {prev, prevPage, pageNumList, current, next, nextPage} = serverData;
  return (
        <Pagination className = "justify-content-center">
          {prev && <Pagination.Prev onClick = {() => moveToList({page : prevPage})}/>}
          {pageNumList.map(pageNum => ( 
            <Pagination.Item key = {pageNum} active = {current === pageNum} onClick = {() => moveToList({page : pageNum})}>{pageNum}</Pagination.Item>))}
          {next && <Pagination.Next onClick = {() => moveToList({page : nextPage})}/>}
        </Pagination>
  );
};

export default PageComponent