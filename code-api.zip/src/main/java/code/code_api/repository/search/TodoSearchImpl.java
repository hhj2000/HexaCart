package code.code_api.repository.search;

import code.code_api.domain.QTodo;
import code.code_api.domain.Todo;
import code.code_api.dto.PageRequestDTO;
import com.querydsl.jpa.JPQLQuery;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.*;
import org.springframework.data.jpa.repository.support.QuerydslRepositorySupport;

import java.util.List;
import java.util.Objects;

@Slf4j
public class TodoSearchImpl extends QuerydslRepositorySupport implements TodoSearch{

    public TodoSearchImpl(){
        super(Todo.class);
    }

    @Override
    public Page<Todo> search1(PageRequestDTO pageRequestDTO){
        log.info("동작하나?");
        QTodo todo = QTodo.todo;
        JPQLQuery<Todo> query = from(todo);

        //query.where(todo.title.contains("1"));
        //페이징처리 추가
        PageRequest pageable = PageRequest.of(
                pageRequestDTO.getPage()-1,
                pageRequestDTO.getSize(),
                Sort.by("tno").descending());
        this.getQuerydsl().applyPagination(pageable, query);
        //Objects.requireNonNull(this.getQuerydsl()).applyPagination(pageable,query);
        List<Todo> list = query.fetch();

        long total = query.fetchCount();
        return new PageImpl<>(list, pageable, total);
    }
}
